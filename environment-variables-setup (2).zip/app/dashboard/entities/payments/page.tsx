'use client'

import { useState } from 'react'
import { CreditCard, Search, Download, Plus, Filter, DollarSign, TrendingUp, AlertCircle, Clock, CheckCircle, RefreshCw } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { StatCard } from '@/components/stats/StatCard'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

const mockPayments = [
  {
    id: 'PAY-56741',
    orderId: 'ORD-12451',
    amount: 450.00,
    method: 'Credit Card',
    status: 'completed',
    date: '2024-02-13',
    customer: 'Ahmed Hassan',
    gateway: 'Stripe',
    transactionId: 'txn_1234567890',
    fee: 13.50,
  },
  {
    id: 'PAY-56740',
    orderId: 'ORD-12450',
    amount: 1200.00,
    method: 'Apple Pay',
    status: 'in_escrow',
    date: '2024-02-13',
    customer: 'Fatima Ali',
    gateway: 'PayPal',
    transactionId: 'txn_0987654321',
    fee: 36.00,
  },
  {
    id: 'PAY-56739',
    orderId: 'ORD-12449',
    amount: 890.50,
    method: 'Bank Transfer',
    status: 'refunded',
    date: '2024-02-12',
    customer: 'Mohammed Khan',
    gateway: 'Bank Direct',
    transactionId: 'txn_bank_12345',
    fee: 0,
    refundedAt: '2024-02-13',
    refundAmount: 890.50,
  },
  {
    id: 'PAY-56738',
    orderId: 'ORD-12448',
    amount: 2450.75,
    method: 'Credit Card',
    status: 'pending',
    date: '2024-02-14',
    customer: 'Layla Ahmed',
    gateway: 'Square',
    transactionId: 'txn_square_789',
    fee: 73.52,
  },
]

export default function PaymentsPage() {
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [methodFilter, setMethodFilter] = useState('all')

  const filteredPayments = mockPayments.filter(payment => {
    const matchesSearch = payment.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         payment.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         payment.orderId.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === 'all' || payment.status === statusFilter
    const matchesMethod = methodFilter === 'all' || payment.method === methodFilter
    return matchesSearch && matchesStatus && matchesMethod
  })

  const stats = {
    totalRevenue: mockPayments.reduce((sum, p) => sum + (p.status !== 'refunded' ? p.amount : 0), 0),
    completed: mockPayments.filter(p => p.status === 'completed').length,
    inEscrow: mockPayments.reduce((sum, p) => p.status === 'in_escrow' ? sum + p.amount : sum, 0),
    refunded: mockPayments.reduce((sum, p) => p.status === 'refunded' ? sum + p.refundAmount! : sum, 0),
    avgFee: (mockPayments.reduce((sum, p) => sum + p.fee, 0) / mockPayments.length).toFixed(2),
  }

  return (
    <div className="flex-1 overflow-auto">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Payments Management</h1>
            <p className="text-muted-foreground mt-2">Monitor transactions, manage refunds, and reconcile payments</p>
          </div>
          <div className="flex gap-2">
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              New Payment
            </Button>
            <Button variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <StatCard 
            title="Total Revenue" 
            value={`$${stats.totalRevenue.toLocaleString('en-US', {minimumFractionDigits: 2})}`} 
            change={18} 
            description="vs last month" 
            icon={<DollarSign className="h-5 w-5" />} 
          />
          <StatCard 
            title="Completed" 
            value={stats.completed} 
            color="success" 
            icon={<CheckCircle className="h-5 w-5" />} 
          />
          <StatCard 
            title="In Escrow" 
            value={`$${stats.inEscrow.toLocaleString('en-US', {minimumFractionDigits: 2})}`} 
            color="warning" 
            icon={<Clock className="h-5 w-5" />} 
          />
          <StatCard 
            title="Refunded" 
            value={`$${stats.refunded.toLocaleString('en-US', {minimumFractionDigits: 2})}`} 
            color="destructive" 
            icon={<RefreshCw className="h-5 w-5" />} 
          />
          <StatCard 
            title="Avg Fee" 
            value={`$${stats.avgFee}`} 
            icon={<TrendingUp className="h-5 w-5" />} 
          />
        </div>

        {/* Search & Filters */}
        <div className="flex flex-col gap-4">
          <div className="flex gap-2">
            <Input 
              placeholder="Search by payment ID, customer, or order..." 
              className="flex-1" 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Button variant="outline"><Search className="h-4 w-4" /></Button>
          </div>
          <div className="flex gap-2">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="All Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="in_escrow">In Escrow</SelectItem>
                <SelectItem value="refunded">Refunded</SelectItem>
              </SelectContent>
            </Select>
            <Select value={methodFilter} onValueChange={setMethodFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="All Methods" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Methods</SelectItem>
                <SelectItem value="Credit Card">Credit Card</SelectItem>
                <SelectItem value="Apple Pay">Apple Pay</SelectItem>
                <SelectItem value="Bank Transfer">Bank Transfer</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" className="ml-auto">
              <Filter className="h-4 w-4 mr-2" />
              More Filters
            </Button>
          </div>
        </div>

        {/* Payments Table */}
        <Tabs defaultValue="all" className="w-full">
          <TabsList>
            <TabsTrigger value="all">All ({filteredPayments.length})</TabsTrigger>
            <TabsTrigger value="completed">Completed ({mockPayments.filter(p => p.status === 'completed').length})</TabsTrigger>
            <TabsTrigger value="pending">Pending ({mockPayments.filter(p => p.status === 'pending').length})</TabsTrigger>
            <TabsTrigger value="escrow">In Escrow ({mockPayments.filter(p => p.status === 'in_escrow').length})</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="mt-4">
            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="border-b border-border bg-muted/50">
                      <tr>
                        <th className="px-6 py-3 text-left font-medium">Payment ID</th>
                        <th className="px-6 py-3 text-left font-medium">Order ID</th>
                        <th className="px-6 py-3 text-left font-medium">Customer</th>
                        <th className="px-6 py-3 text-left font-medium">Amount</th>
                        <th className="px-6 py-3 text-left font-medium">Method</th>
                        <th className="px-6 py-3 text-left font-medium">Status</th>
                        <th className="px-6 py-3 text-left font-medium">Gateway</th>
                        <th className="px-6 py-3 text-left font-medium">Date</th>
                        <th className="px-6 py-3 text-right font-medium">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {filteredPayments.length === 0 ? (
                        <tr>
                          <td colSpan={9} className="px-6 py-8 text-center text-muted-foreground">No payments found</td>
                        </tr>
                      ) : (
                        filteredPayments.map((payment) => (
                          <tr key={payment.id} className="hover:bg-muted/50 transition-colors">
                            <td className="px-6 py-4">
                              <span className="font-semibold">{payment.id}</span>
                            </td>
                            <td className="px-6 py-4">{payment.orderId}</td>
                            <td className="px-6 py-4">{payment.customer}</td>
                            <td className="px-6 py-4 font-semibold">${payment.amount.toFixed(2)}</td>
                            <td className="px-6 py-4">
                              <Badge variant="outline">{payment.method}</Badge>
                            </td>
                            <td className="px-6 py-4">
                              <Badge variant={
                                payment.status === 'completed' ? 'default' :
                                payment.status === 'pending' ? 'secondary' :
                                payment.status === 'in_escrow' ? 'secondary' :
                                'destructive'
                              }>
                                {payment.status.replace('_', ' ')}
                              </Badge>
                            </td>
                            <td className="px-6 py-4 text-xs">{payment.gateway}</td>
                            <td className="px-6 py-4 text-muted-foreground text-xs">{payment.date}</td>
                            <td className="px-6 py-4 text-right">
                              {payment.status === 'completed' && (
                                <Button size="sm" variant="ghost">Refund</Button>
                              )}
                              {payment.status !== 'completed' && (
                                <Button size="sm" variant="ghost">View</Button>
                              )}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="completed" className="mt-4">
            <Card>
              <CardContent className="p-6">
                <div className="text-center text-muted-foreground">Completed payments view</div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="pending" className="mt-4">
            <Card>
              <CardContent className="p-6">
                <div className="text-center text-muted-foreground">Pending payments view</div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="escrow" className="mt-4">
            <Card>
              <CardContent className="p-6">
                <div className="text-center text-muted-foreground">Payments in escrow view</div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
