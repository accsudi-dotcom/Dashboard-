import { ValueObject } from '@/core/domain/ValueObject'
import { InvalidArgumentError } from '@/core/domain/errors/DomainError'

export class UserPassword extends ValueObject<{ hash: string; salt: string }> {
  validate(value: { hash: string; salt: string }): void {
    if (!value.hash || !value.salt) {
      throw new InvalidArgumentError('Invalid password format')
    }
  }

  static create(plainPassword: string): UserPassword {
    // In production: use bcrypt.hash() with salt rounds
    const salt = Math.random().toString(36).substring(7)
    const hash = `${plainPassword}:${salt}` // Simplified - use proper hashing in prod
    return new UserPassword({ hash, salt })
  }

  matches(plainPassword: string): boolean {
    // In production: use bcrypt.compare()
    const testHash = `${plainPassword}:${this.value.salt}`
    return testHash === this.value.hash
  }

  toPrimitives(): Record<string, any> {
    return {
      hash: this.value.hash,
      salt: this.value.salt,
    }
  }
}
